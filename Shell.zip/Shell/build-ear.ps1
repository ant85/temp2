

#### Description: -Finds dependent modules (TIBCO.xml) for a given application and imports them into a new BW workspace
####              -Builds new ear
####
#### Written by:  Jakub Bruzdzinski - jakub.bruzdzinski@dxc.com
#### Change log:  18/05/2017 | Jakub Bruzdzinski | script created
####              24/05/2017 | Jakub Bruzdzinski | added svn update with cert trust
####              26/05/2017 | Jakub Bruzdzinski | added validations
#### 			  28/05/2017 | Jakub Bruzdzinski | added snapshot upload
#### 			  29/07/2017 | Jakub Bruzdzinski | added svn revert
#### 			  31/07/2017 | Jakub Bruzdzinski | added svn commit

Param(
  [string]$application,
  [string]$build_name,
  [string]$is_snapshot,
  [string]$release_type
)



$start_ts = (Get-Date)

$source_path = "D:\Jenkins\source\"
$build_path = "D:\Jenkins\workspace\" + $build_name
$bwdesign = "C:\tibco634\bw\6.3\bin\bwdesign.exe --propFile C:\tibco634\bw\6.3\bin\bwdesign.tra"
$bwdesign_import = $bwdesign + " -data " + $build_path + " import "
$bwdesign_export = $bwdesign + " -data " + $build_path + " export force -e " + $application + " " + $build_path
$bwdesign_validate = $bwdesign + " -data " + $build_path + " validate "



#### Update BW source code
$cmd_svn_revert = "svn -R revert --trust-server-cert --non-interactive " + $source_path + $application +"\META-INF\"
Invoke-Expression $cmd_svn_revert

$cmd_svn_update = "svn update --trust-server-cert --non-interactive " + $source_path
Invoke-Expression $cmd_svn_update

$cmd_svn_revision = "svn info --trust-server-cert --non-interactive " + $source_path
$svn_revision = Invoke-Expression $cmd_svn_revision | Select-String -Pattern "Revision:.*"


### Read TIBCO.xml file
$config_file = $source_path + $application + "\META-INF\TIBCO.xml"
IF(Test-Path $config_file){
Write-Host "INFO`t" Reading module from configuration file: $config_file

}
Else{
Write-Host "INFO`t" Configuration file $config_file does not exist
Exit 1
}

[xml] $xml = Get-Content $config_file	

### Find modules in TIBCO.xml
$modules = $xml.'packageUnit'.'modules'.'module'.'symbolicName'

### Construct import command by appending BW modules
$bwdesign_import_modules = $bwdesign_import + $source_path + $application


ForEach ($module in $modules) {

	$bwdesign_import_modules = $bwdesign_import_modules + "," + $source_path + $module
	Write-Host "INFO`t" $module
	Write-Host "INFO`t" $bwdesign_import_modules
 
	 }

### Read MANIFEST.MF file
$manifest_file = $source_path + $application + "\META-INF\MANIFEST.MF"

$manifest_map = convertfrom-stringdata((get-content $manifest_file -raw).replace(":","="))
$application_name=$manifest_map."Bundle-SymbolicName"
$application_version=$manifest_map."Bundle-Version"
### Get rid of '.qualifier'
#$application_version=$application_version.Substring(0,$application_version.LastIndexof("."))
$version_array=$application_version.Split(".")
#$version_array
$major=$version_array[0]
$minor=$version_array[1]
$build=$version_array[2]

#Write-Host "INFO `t" Major is $major
#Write-Host "INFO `t" Minor is $minor
#Write-Host "INFO `t" Build is $build

IF($release_type -eq "Major"){
$major_next=[int]$major + 1
$minor_next=[int]0
$build_next=[int]1
}
ElseIf($release_type -eq "Minor"){
$major_next=[int]$major
$minor_next=[int]$minor + 1
$build_next=[int]1
}
Else{
$major_next=[int]$major
$minor_next=[int]$minor
$build_next=[int]$build + 1
}




#$version_next= "Bundle-Version: " + $major_next.toString("00")+"." + $minor_next.toString("00")+"."+$build_next.toString("000")+"."+ "qualifier"

#Remove qualifier
$version_next= "Bundle-Version: " + $major_next.toString("00")+"." + $minor_next.toString("00")+"."+$build_next.toString("000")

$application_version_next= $major_next.toString("00")+"." + $minor_next.toString("00")+"."+$build_next.toString("000")

(Get-Content $manifest_file) | Foreach-Object {$_ -replace '^Bundle-Version: .+$',$version_next } | Set-Content -Path $manifest_file



Write-Host "INFO `t" Building archive $application_version_next...

### Read TIBCO.xml file
$tibco_xml_file = $source_path + $application + "\META-INF\TIBCO.xml"
[xml] $xml = Get-Content $tibco_xml_file	



IF($is_snapshot -eq "Y"){
$xml.packageUnit.description = $application_version_next + "-SNAPSHOT, " + $svn_revision
}
Else{
$xml.packageUnit.description = $application_version_next + ", " + $svn_revision
}


$description
$xml.Save($tibco_xml_file)


### Import modules into workspace - use () to output result to console and variable at the same time
($bwdesign_import_modules_out = Invoke-Expression $bwdesign_import_modules)

IF($bwdesign_import_modules_out -match [regex]::escape("0 task(s) failed")){

Write-Host "INFO`t" All modules loaded successfully

}
Else{
Write-Host "INFO`t" Import failed
Exit 1
}

## Validate workspace
($bwdesign_validate_out = Invoke-Expression $bwdesign_validate)

IF($bwdesign_validate_out -cmatch [regex]::escape("ERROR")){

Write-Host "INFO`t" Workspace validation failed
Exit 1
}
Else{
Write-Host "INFO`t" Workspace validation passed

}
##Build ear
Invoke-Expression $bwdesign_export


### Look for ear in build folder
$application_ear_path = (Get-Childitem -Path $build_path -Filter *.ear).FullName
Write-Host "INFO`t" Application ear exported $application_ear_path

### Upload snapshot to Nexus

Write-Host %JAVA_HOME%

& '.\upload-snapshot.ps1' -application_ear_path $application_ear_path -application_name $application_name -application_version $application_version_next -is_snapshot $is_snapshot


### Calculate total job time	 
$end_ts = (Get-Date)
$ts = (New-TimeSpan -Start $start_ts -End $end_ts)



IF($is_snapshot -eq "Y"){
$cmd_svn_revert = "svn -R revert --trust-server-cert --non-interactive " + $source_path + $application +"\META-INF\"
Invoke-Expression $cmd_svn_revert
#svn -R revert D:\Jenkins\source\
}
Else{
$commit_message = "'Jenkins:" +$build_name +" Building release version: " +$application_version_next + "' "
$cmd_svn_commit = "svn commit --trust-server-cert --non-interactive --message " + $commit_message + $source_path + $application +"\META-INF\"
Invoke-Expression $cmd_svn_commit
}

#$cmd_svn_revert = "svn -R revert --trust-server-cert --non-interactive " + $source_path + $application +"\META-INF\"
#Invoke-Expression $cmd_svn_revert
#svn -R revert D:\Jenkins\source\

Write-Host "The application ear was generated and uploaded successfully. It took $($ts.hours):$($ts.minutes):$($ts.seconds),$($ts.milliseconds) to run "




	