

#### Description: -Finds dependent modules (TIBCO.xml) for a given application and imports them into a new BW workspace
####              -Builds new ear
####
#### Written by:  Jakub Bruzdzinski - jakub.bruzdzinski@dxc.com
#### Change log:  28/05/2017 | Jakub Bruzdzinski | script created
####              02/06/2017 | Jakub Bruzdzinski | added path parser
####              26/05/2017 | Jakub Bruzdzinski | configured with snapshot upload

Param(
  [string]$application_ear_path, 
  [string]$application_name,
  [string]$application_version,
  [string]$is_snapshot
)



$application_group= "tibco.esb" 

IF($is_snapshot -eq "Y"){

$application_version=$application_version+"-SNAPSHOT"
$repo_url="http://30.185.15.37:9111/content/repositories/snapshots"
}
Else{
$application_version=$application_version
$repo_url="http://30.185.15.37:9111/content/repositories/releases"

}




$env:JAVA_HOME = "C:\Program Files (x86)\Java\jdk1.7.0_79\jre"
$env:JAVA_HOME
$nexus_upload = "mvn deploy:deploy-file '-DgroupId=$application_group' '-DartifactId=$application_name' '-Dversion=$application_version' '-Dpackaging=ear' '-Dfile=$application_ear_path' '-DgeneratePom=true' '-DrepositoryId=nexus' '-Durl=$repo_url'"

$nexus_upload
Invoke-Expression $nexus_upload
	 
	






	