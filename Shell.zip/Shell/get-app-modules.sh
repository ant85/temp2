#!/bin/bash
########################################################################################################
#### Description: Gets application modules out of BW configuration file TIBCO.xml 
####		  
####
#### Written by:  Jakub Bruzdzinski - jakub.bruzdzinski@hpe.com
#### Change log:  21/09/2016 | Jakub Bruzdzinski | script created
####             
####
########################################################################################################


PROGRAM_NAME=$0
APP_CONFIG=$1



function usage {
    echo "usage: $PROGRAM_NAME [TIBCO.xml]"
    echo "Provide an absolute path to TIBCO.xml configuration file "
    echo "eg. $PROGRAM_NAME /opt/tibco/ws/co.uk.lbs.logaudit.application/METAINF/TIBCO.xml"
    exit 1
}


if [ ${#@} -ne 1 ]; then
    usage
    exit 1
fi

#check if  TIBCO.xml file exists
if [ ! -f ${APP_CONFIG} ];then
        echo "Configuration file TIBCO.xml does not exist"
        exit 1
fi


XPATH="setns packaging=http://schemas.tibco.com/tra/model/core/PackagingModel
xpath //packaging:symbolicName/text()
exit"


COMMAND="$(xmllint --shell $APP_CONFIG << EOF
$XPATH
EOF
)"

MODULES=$(echo "{$COMMAND}" | grep content | cut -d '=' -f2)


#for i in $MODULES; do
#echo $i
#done


echo -e "\nApplication modules: \n${MODULES}"
