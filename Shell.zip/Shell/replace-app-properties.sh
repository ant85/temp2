#!/bin/bash
########################################################################################################
#### Description: Replaces application properties based on environment profile 
####		  
####
#### Written by:  Jakub Bruzdzinski - jakub.bruzdzinski@hpe.com
#### Change log:  26/09/2016 | Jakub Bruzdzinski | script created
####             
####
########################################################################################################


PROGRAM_NAME=$0
APP_PROFILE_FILE=${1}
MODULES=${2}
ENV_PROFILE=${3}


function usage {
    echo "usage: $PROGRAM_NAME [APPLICATION PROPERTIES FILE] [MODULES LIST] [PROFILE]"
    echo "Provide an absolute path to application properties .substvar file, followed by application modules and environment profile "
    echo "eg. $PROGRAM_NAME /opt/tibco/ws/co.uk.lbs.logaudit.application/METAINF/default.substvar co.uk.lbs.logaudit co.uk.lbs.common.shared DEV.env"
    exit 1
}


if [ ${#@} -ne 3 ]; then
    usage
    exit 1
fi

#check if  profile .substvar file exists
if [ ! -f ${APP_PROFILE_FILE} ];then
        echo -e "\nApplication properties file ${APP_PROFILE_FILE} does not exist\n"
        exit 1
fi


echo -e "\nReplacing properties in modules...\n"

for MODULE in $MODULES
	do
	echo -e "\nFound module ${MODULE}"
	#export xml processing output to a variable
	xpath_result="$(xmllint --shell --noout ${APP_PROFILE_FILE} < ${ENV_PROFILE}/${MODULE} 2>&1 | grep -v " value " )"
	#check if the output contains error (strip off white chars)	
		if [[ -z "${xpath_result// }" ]];then
			echo -e "\n Application properties replaced successfully \n"
		else
			echo -e "\n Application properties replaced with error \n"
			echo -e $xpath_result
		## comment this line to allow script to execute despite missing elements
		##	exit 1
		fi
	
done
