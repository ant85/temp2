#!/bin/bash
########################################################################################################
#### Description: Creates a new application profile by extracting it from a BW archive 
####		  
####
#### Written by:  Jakub Bruzdzinski - jakub.bruzdzinski@hpe.com
#### Change log:  30/09/2016 | Jakub Bruzdzinski | script created
####             
####
########################################################################################################

PROGRAM_NAME=$0


function usage {
    echo "usage: $PROGRAM_NAME [APPLICATION EAR] [ENV PROFILE]"
    echo "Provide an absolute path to BW application archive - ear , followed by environment profile file"
    echo "eg. $PROGRAM_NAME /opt/tibco/ws/co.uk.lbs.logaudit.application.ear DEV"
    exit 1
}


if [ ${#@} -ne 2 ]; then
    usage
    exit 1
fi


#change home directory to make script portable

HOME_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd ${HOME_DIR}

#set archive variables
ARCHIVE_PATH="${1}"
ARCHIVE_NAME=$(basename ${ARCHIVE_PATH})
APP_NAME=$(echo ${ARCHIVE_NAME} | sed 's/.ear//' )
ENV_PROFILE="./Profiles/${2}"
JOB_DATA="jobdata.conf"

#check if the archive exists
if [ ! -f ${ARCHIVE_PATH} ];then
        echo "Archive does not exist"
        exit 1
fi

#check if the profile exists
if [ ! -d ${ENV_PROFILE} ];then
        echo "Application profile file does not exist"
        exit 1
fi


#execute script in the same shell to keep shell variables
. ./get-app-profile.sh ${ARCHIVE_PATH}

. ./get-app-modules.sh ${OUTPUT_DIR}/${APP_CONFIG}


#replace application properties with environment variables 

. ./replace-app-properties.sh "${OUTPUT_DIR}/${APP_PROFILE}" "${MODULES}" "${ENV_PROFILE}"

#write job variable to a file
echo "OUTPUT_DIR=${OUTPUT_DIR}" >> ${OUTPUT_DIR}/${JOB_DATA}
echo "APP_NAME=${APP_NAME}" >> ${OUTPUT_DIR}/${JOB_DATA}





