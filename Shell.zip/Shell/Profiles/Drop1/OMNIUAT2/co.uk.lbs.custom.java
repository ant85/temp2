setns x=http://www.tibco.com/xmlns/repo/types/2002 
 
cd /x:repository/x:globalVariables/x:globalVariable[x:name = '//co.uk.lbs.custom.java//BW.HOST.NAME']/x:value
set localhost
save 
bye