#!/bin/bash
########################################################################################################
#### Description: Checks application status in a domain along with server utilization
####
#### Written by:  Haripada Dey- haripada.dey@hpe.com
#### Change log:  10/07/2017 | Haripada Dey | script created
####             
####
########################################################################################################
DOMAIN=${1}

echo "START"
echo "=================================================="
echo "Checking status on $(hostname -f)"
echo "====================Disk space====================="
df -h |grep tibco| awk '{print $5,$4}'
echo "============================Date-Time======================"
date
echo "================ Application Status for ${DOMAIN} Enviornment ================"
bwadmin show -domain ${DOMAIN} applications |grep co.uk.lbs| awk '{print $1,$3,$5}'|column -t

echo "END"
