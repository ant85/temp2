#!/bin/bash
########################################################################################################
#### Description: Extracts default application profile from application archive.  
####		      Output location is pre-set.
####
#### Written by:  Jakub Bruzdzinski - jakub.bruzdzinski@hpe.com
#### Change log:  30/09/2016 | Jakub Bruzdzinski | script created
####             
####
########################################################################################################

PROGRAM_NAME=$0


function usage {
    echo "usage: $PROGRAM_NAME [APPLICATION.EAR]"
    echo "Provide an absolute path to BW application archive - ear "
	echo "Output directory will be determined and created automatically"
    echo "eg. $PROGRAM_NAME /opt/tibco/ws/co.uk.lbs.logaudit.application.ear"
    exit 1
}


if [ ${#@} -ne 1 ]; then
    usage
    exit 1
fi



#set archive variables
ARCHIVE_PATH="${1}"
ARCHIVE_NAME=$(basename ${ARCHIVE_PATH})
APP_NAME=$(echo ${ARCHIVE_NAME} | sed 's/.ear//' )
APP_PROFILE="META-INF/default.substvar"
APP_CONFIG="META-INF/TIBCO.xml"
TIMESTAMP=$(date +%Y%m%d%H%M%S)

#check if the archive exists
if [ ! -f ${ARCHIVE_PATH} ];then
        echo "Archive does not exist"
        exit 1
fi



#set output directory
if [ ${BUILD_NUMBER} ]
	then echo -e "Script has been run from Jenkins. Build number is: ${BUILD_NUMBER}\n"
	OUTPUT_DIR="${JENKINS_HOME}/jobs/$(dirname ${JOB_NAME})/builds/${BUILD_NUMBER}"	
	else echo -e "Script has been run outside of Jenkins \n"
	OUTPUT_DIR="/home/tibco/ws/${TIMESTAMP}"
fi



#exract application profile and configuration file to output directory
unzip ${ARCHIVE_PATH} ${APP_PROFILE} ${APP_CONFIG} -d ${OUTPUT_DIR}


echo -e "\nApplication profile has been created: ${OUTPUT_DIR}/${APP_PROFILE}"


