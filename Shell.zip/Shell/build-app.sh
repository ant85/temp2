#!/bin/bash
#interpreter for the script

##NOTE#################
## script originated from /Omni/scripts
## look at revision history to roll back modification as a result of bug testing with bwdesign

#### Description: Finds dependent modules for a given application and imports them into a new BW workspace
####                      Dependencies are included in TIBCO.xml file of the application
####
#### Written by:  Jakub Bruzdzinski - jakub.bruzdzinski@hpe.com
#### Change log:  14/08/2016 | Jakub Bruzdzinski | script created
####              17/08/2016 | Jakub Bruzdzinski | added XPath command
####              28/08/2016 | Jakub Bruzdzinski | added bwdesign import

PROGRAM_NAME=$0


function usage {
    echo "usage: $PROGRAM_NAME [repository path] [application name]"
    echo "Specify repository path with BW projects followed by an application name "
    echo "eg. get-modules /opt/tibco/ws co.uk.lbs.logaudit.application"
    exit 1
}


if [ ${#@} -ne 2 ]; then
    usage
    exit 1
fi

#Check and set environment
export DISPLAY=:1


#Set variables
BASE_DIR="${1}"
APP_NAME="${2}"
APP_DIR="${1}/${2}"
APP_CONFIG="${1}/${2}/META-INF/TIBCO.xml"
DATE=$(date +%y%m%d%H%M%S)



#Validate if configuration file exists

if [ -f ${APP_CONFIG} ]
then
        echo "Configuration file found: $APP_CONFIG"
else
        echo "Configuration file not found: $APP_CONFIG"
        exit 1
fi

#Validate if Jenkins environment variable BUILD_NUMBER is set
echo ${BUILD_NUMBER}
if [ -z ${BUILD_NUMBER} ]
then
	WS_DIR="/home/tibco/ws/${DATE}-${APP_NAME}"
    echo "Workspace is: ${WS_DIR}"
else
	WS_DIR="/devtools/data/jenkins/jobs/tibco-omni-build/builds/${BUILD_NUMBER}/BW"
    echo "Workspace is: ${WS_DIR}"
fi

mkdir ${WS_DIR}

#Set XPath formula to select BW packages from TIBCO.xml
XPATH="setns packaging=http://schemas.tibco.com/tra/model/core/PackagingModel
xpath //packaging:symbolicName/text()
exit"

#Set XML processor command with application config file and XPath
COMMAND="$(xmllint --shell $APP_CONFIG  << EOF
$XPATH
EOF
)"

#Get dependent modules
MODULES=$(echo "{$COMMAND}" | grep content | cut -d '=' -f2)

#Add application to the list of modules
MODULES=$(echo ${MODULES} ${APP_NAME})

echo $MODULES

#for MODULE in ${MODULES}; do
#find "${BASE_DIR}/${MODULE}" -type d -name .svn -print0|xargs -0 rm -rf
#done

for MODULE in ${MODULES}; do
cp -r "${BASE_DIR}/${MODULE}" ${WS_DIR}
done


for MODULE in ${MODULES}; do
find "${WS_DIR}" -type d -name .svn -print0|xargs -0 rm -rf
done

IS_FIRST=1
for MODULE in ${MODULES}; do
        if [ ${IS_FIRST} -eq 1 ]
        then
            MODULES_STRING="${WS_DIR}/${MODULE}"
            IS_FIRST=0
        else
            MODULES_STRING="${MODULES_STRING},${WS_DIR}/${MODULE}"
        fi
done
echo $MODULES_STRING


cd /opt/tibco/bw63/bw/6.3/bin/
./bwdesign -data ${WS_DIR} import ${MODULES_STRING}
echo ${WS_DIR}
chmod -R 777 ${WS_DIR}
./bwdesign -data ${WS_DIR} export -e ${APP_NAME} ${WS_DIR}/EAR
#sudo -u tibco ./bwdesign -data ${WS_DIR} import ${MODULES_STRING}
#sudo -u tibco ./bwdesign -data ${WS_DIR} export -e ${APP_NAME} /home/tibco/ear
