#!/bin/bash
########################################################################################################
#### Description: Checks application status in a domain along with server utilization
####
#### Written by:  Jakub Bruzdzinski - jakub.bruzdzinski@hpe.com
#### Change log:  14/05/2017 | Jakub Bruzdzinski | script created
####             
####
########################################################################################################
DOMAIN=${1}

echo "START"
echo "=================================================="
echo "Checking status on $(hostname -f)"
echo "====================Disk space====================="
df -h |grep tibco| awk '{print $5,$4}'
echo "============================Date-Time======================"
date
echo "================ Application Status================"
bwadmin show -domain ${DOMAIN} applications |grep co.uk.lbs| awk '{print $1,$3,$5}'|column -t

echo "END"
